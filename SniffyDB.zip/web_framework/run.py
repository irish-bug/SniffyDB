#!flask/bin/python
from app import app

__author__ = "Donald Cha"
app.run(host="0.0.0.0", debug=True)
